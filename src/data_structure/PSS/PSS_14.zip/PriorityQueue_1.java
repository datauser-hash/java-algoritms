
public static int[] switchSigns( int[] data, int k ) {
	PriorityQueue<Integer,Integer> pq = new PriorityQueue<Integer,Integer>();
	// Put all numbers into priority queue
	for ( int item : data )
		pq.insert( item, 0 );
	// Repeat 'k' times
	while ( k-- > 0 ) {
		int num = pq.removeMin().getKey();
		num = -num;
		pq.insert( num, 0 );
	}
	// Put back into the array
	for ( int i = 0; i < data.length; ++i )
		data[ i ] = pq.removeMin().getKey();
}
