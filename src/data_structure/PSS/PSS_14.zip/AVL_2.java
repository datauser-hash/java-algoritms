
public static ArrayList<Integer> intersection( 
		Node<Integer> aRoot, 
		Node<Integer> bRoot ) {
	// Convert 'a' to list
	ArrayList<Integer> aList;
	inorder( aRoot, aList );
	// Convert 'b' to list
	ArrayList<Integer> bList;
	inorder( bRoot, bList );
	// Find the intersection
	ArrayList<Integer> result;
	int i = 0, j = 0;
	while ( i < aList.size() && i < bList.size() ) {
		if ( a.get(i) == b.get(j) ) {
			// Match found: put it into result
			result.add( a.get(i) );
			//   advance in both lists
			++i;
			++j;
		}
		else if ( a.get(i) < b.get(j) ) {
			// Need to move forward on 'a'
			++i;
		}
		else {  //  a.get(i) > b.get(j)
			// Need to move forward on 'b'
			++j;
		}
	}
	return result;
}
