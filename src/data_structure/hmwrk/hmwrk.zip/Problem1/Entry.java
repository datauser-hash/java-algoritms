package data_structure.hmwrk.Problem1;


public interface Entry<K, V> {
    K getKey();
    V getValue();
}
