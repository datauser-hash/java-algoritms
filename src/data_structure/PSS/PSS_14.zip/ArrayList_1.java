
/**
 * Complexity is O(N*M)
 */
public static ArrayList<Integer> difference_very_slow( 
		ArrayList<Integer> a, ArrayList<Integer> b ) {
	ArrayList<Integer> result;
	for ( int i = 0; i < a.size(); ++i ) {
		// Check if a[i] is present in 'b'
		boolean isPresent = false;
		for ( int j = 0; j < b.size(); ++j )
			if ( a.get(i) == b.get(j) )
				isPresent = true;
		// Add to result, if absent
		if ( ! isPresent )
			result.add( a.get(i) );
	}
	return result;
}


/**
 * Complexity is O((N+M)*logM)
 */
public static ArrayList<Integer> difference( 
		ArrayList<Integer> a, ArrayList<Integer> b ) {
	ArrayList<Integer> result;
	// Sort 'b' array
	Collections.sort( b );
	for ( int i = 0; i < a.size(); ++i ) {
		// Check if a[i] is present in 'b', & add to result
		if ( Collections.binarySearch( b, a.get(i) ) < 0 )
			result.add( a.get(i) );
	}
	return result;
}
