
public static Pair<Integer,Integer> minUnsortedRange( int[] data ) {
	// Find start position
	int lastMinNotUpdated = data.length;
	int lastMin = data[ data.length - 1 ];
	for ( int i = data.length - 2; i >= 0; --i ) {
		if ( data[ i ] < lastMin )
			lastMin = data[ i ];
		else
			lastMinNotUpdated = i;
	}
	// Find finish position
	int lastMaxNotUpdated = -1;
	int lastMax = data[ 0 ];
	for ( int i = 1; i < data.length; ++i ) {
		if ( data[ i ] > lastMax )
			lastMax = data[ i ];
		else
			lastMaxNotUpdated = i;
	}
	// Combine results
	if ( lastMinNodUpdated > lastMaxNotUpdated )
		return new Pair<Integer,Integer>( -1, -1 );
	else
		return new Pair<Integer,Integer>( lastMinNotUpdated, lastMaxNotUpdated );
}
