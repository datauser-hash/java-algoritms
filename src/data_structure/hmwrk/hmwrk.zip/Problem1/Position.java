package data_structure.hmwrk.Problem1;


public interface Position<E>{
    E getElement() throws IllegalStateException;
}
